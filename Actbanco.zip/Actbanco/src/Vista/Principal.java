
package Vista;

import Modelo.Banco;
import Modelo.Cuenta;
import Modelo.Sede;
import Modelo.Usuario;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Principal {
    public static void main(String[] args) {
        //****************************Menu******************************************
        int accion;
        int op;
        ArrayList<Usuario> listaUsuarios = new ArrayList<Usuario>();
        ArrayList<Banco> listaBancos = new ArrayList<Banco>();
        ArrayList<Sede> listaSedes = new ArrayList<Sede>();
        ArrayList<Cuenta> listaCuentas = new ArrayList<Cuenta>();
        
        do
        {
            accion = new Integer(JOptionPane.showInputDialog("******  Menu de opciones  *******\n\n"
                    + "1. Crear un banco\n"
                    + "2. Crear sedes\n"
                    + "3. Crear cuenta bancaria\n"
                    + "4. Crear usuario\n"
                    + "5. Listado e info de todas las sedes\n"
                    + "6. Realizar consulta de sede por su codigo\n"
                    + "7. Realizar consulta de cuenta bancaria\n"
                    + "8. Abandonar proceso o salir\n"));
            switch(accion){
                case 1:{
                    String id = JOptionPane.showInputDialog("Digite el ID del nuevo banco");
                    String nombre = JOptionPane.showInputDialog("Digite el nombre del nuevo banco");
                    Banco banco = new Banco(id, nombre);
                    listaBancos.add(banco);
                    JOptionPane.showMessageDialog(null, "Banco creado con exito");
                    break;
                }
                case 2:{
                    String datos = "Elija un banco para crear la nueva sede\n";
                    for (int i=0; i<listaBancos.size(); i++){
                        datos += i + ": " + listaBancos.get(i).datosBanco();
                    }
                    op = new Integer(JOptionPane.showInputDialog(datos));
                    Sede sede = listaBancos.get(op).crearSede();
                    listaSedes.add(sede);
                    break;
                }
                case 3:{
                    String datos1 = "Elija un banco para crear la nueva cuenta\n";
                    for (int i=0; i<listaBancos.size(); i++){
                        datos1 += i + ": " + listaBancos.get(i).datosBanco();
                    }
                    op = new Integer(JOptionPane.showInputDialog(datos1));
                    ArrayList<Sede> lsSedes = listaBancos.get(op).getSedes();
                    
                    String datos2 = "Elija una sede del banco para crear la nueva cuenta\n";
                    for (int i=0; i<lsSedes.size(); i++){
                        datos2 += i + ": " + lsSedes.get(i).datosSede();
                    }
                    op = new Integer(JOptionPane.showInputDialog(datos2));
                    Cuenta c = lsSedes.get(op).crearCuenta(listaUsuarios);
                    if(listaCuentas.size() < 10){
                        listaCuentas.add(c);
                    }
                    break;
                }
                case 4:{
                    String nombre = JOptionPane.showInputDialog("Digite el nombre del nuevo usuario");
                    String apellido = JOptionPane.showInputDialog("Digite el nombre del nuevo usuario");
                    String cc = JOptionPane.showInputDialog("Digite el nombre del nuevo usuario");
                    String sexo = JOptionPane.showInputDialog("Digite el nombre del nuevo usuario");
                    Usuario usuario = new Usuario(nombre, apellido, cc, sexo);
                    listaUsuarios.add(usuario);
                    JOptionPane.showMessageDialog(null, "Usuario crado con exito");
                    break;
                }
                case 5:{
                    String datos = "";
                    for(Sede sede: listaSedes){
                        datos = sede.toString();
                        JOptionPane.showMessageDialog(null, datos);
                    }
                    break;
                }
                case 6:{
                    String codigo = JOptionPane.showInputDialog("Digite el codigo de la sede a consultar");
                    String datos = "";
                    boolean sw = false;
                    for (int i=0; i<listaSedes.size(); i++){
                        if(listaSedes.get(i).getCodigo().equals(codigo)){
                            datos = listaSedes.get(i).toString();
                            sw = true;
                            break;
                        }
                    }
                    if(sw){
                        JOptionPane.showMessageDialog(null, datos);
                    }else{
                        JOptionPane.showMessageDialog(null, "No hay una sede con ese codigo");
                    }
                    break;
                }
                case 7:{
                    int codCuenta = new Integer(JOptionPane.showInputDialog("Digite el codigo de la cuenta bancaria a consultar"));
                    String datos = "";
                    boolean sw = false;
                    for (int i=0; i<listaCuentas.size(); i++){
                        if(listaCuentas.get(i).getNumCuenta() == codCuenta){
                            datos = listaCuentas.get(i).toString();
                            sw = true;
                            break;
                        }
                    }
                    if(sw){
                        JOptionPane.showMessageDialog(null, datos);
                    }else{
                        JOptionPane.showMessageDialog(null, "No hay una cuenta con ese codigo");
                    }
                    break;
                }
                case 8:{
                    JOptionPane.showMessageDialog(null, "Saliendo del programa");
                    return;
                }
                default:{
                    JOptionPane.showMessageDialog(null, "Opcion invalida.");
                    break;
                }
            }

        }while(true);
    }
}
