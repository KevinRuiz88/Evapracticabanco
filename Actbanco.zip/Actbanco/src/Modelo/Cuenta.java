
package Modelo;

public class Cuenta {
    private int numCuenta;
    private String tipoCuenta;
    private Usuario titular;
    private Double saldoinicial;
    private Double saldo;

    public Cuenta(int numCuenta, String tipoCuenta, Usuario titular, Double saldoinicial) {
        this.numCuenta = numCuenta;
        this.tipoCuenta = tipoCuenta;
        this.titular = titular;
        this.saldoinicial = saldoinicial;
        this.saldo = saldoinicial;
    }

    public int getNumCuenta() {
        return numCuenta;
    }

    public void setNumCuenta(int numCuenta) {
        this.numCuenta = numCuenta;
    }

    public String getTipoCuenta() {
        return tipoCuenta;
    }

    public void setTipoCuenta(String tipoCuenta) {
        this.tipoCuenta = tipoCuenta;
    }

    public Usuario getTitular() {
        return titular;
    }

    public void setTitular(Usuario titular) {
        this.titular = titular;
    }

    public Double getSaldoinicial() {
        return saldoinicial;
    }

    public Double getSaldo() {
        return saldo;
    }

    public void setSaldo(Double saldo) {
        this.saldo = saldo;
    }
    
     @Override
    public String toString (){
        String datos = "";
        datos += "\nDatos de la cuenta\n";
        datos += "Numero de cuenta: " + this.getNumCuenta() + "\n";
        datos += "Tipo de cuenta: " + this.getTipoCuenta() + "\n";
        datos += "Saldo inicial: " + this.getSaldoinicial() + "\n";
        datos += "Saldo actual: " + this.getSaldo() + "\n";
        datos += "nTitular: " + this.getTitular().toString() + "\n";
        return datos;
    }
}
