
package Modelo;

import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Sede{
    private String codigo;
    private String nombre;
    private String direccion;
    private String ciudad;
    private int cantidadCuentas;
    private ArrayList<Cuenta> listaCuentas;

    public Sede(String codigo, String nombre, String direccion, String ciudad) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.direccion = direccion;
        this.ciudad = ciudad;
        this.cantidadCuentas = 0;
        this.listaCuentas = new ArrayList<Cuenta>();
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public int getCantidadCuentas() {
        return cantidadCuentas;
    }

    public void setCantidadCuentas(int cantidadCuentas) {
        this.cantidadCuentas = cantidadCuentas;
    }

    public ArrayList<Cuenta> getListaCuentas() {
        return listaCuentas;
    }

    public void setListaCuentas(ArrayList<Cuenta> listaCuentas) {
        this.listaCuentas = listaCuentas;
    }
    
    //Inserta una cuenta en la lista de cuentas
    private boolean insertarCuenta(Cuenta cuenta){
        if(this.getCantidadCuentas()<10){
            this.listaCuentas.add(cuenta);
            System.out.println("Cuenta insertada con exito\n");
            this.setCantidadCuentas(this.getCantidadCuentas()+1);
            return true;
        }else{
            System.out.println("La cantidad de cuentas no pueden ser mayores que 10\n");
        }
        return false;
    }
    
    //Crea una sede pidiendo sus datos y la retorna
    public Cuenta crearCuenta(ArrayList<Usuario> listaUsuarios){
        Cuenta cuenta = null;
        int op;
        int numCuenta = new Integer(JOptionPane.showInputDialog("Digite el numero de la cuenta"));
        String tipoCuenta;
        int tipo = new Integer(JOptionPane.showInputDialog("Digite el tipo de cuenta\n 1: Corriente\n2. Ahorro"));
        if(tipo == 1){
            tipoCuenta = "Corriente";
        }else{
            tipoCuenta = "Ahorro";
        }
        Double saldoinicial = new Double(JOptionPane.showInputDialog("Digite el saldo inicial de la cuenta"));
        String datos = "Elija el titular de la cuenta.\n";
        for (int i=0; i<listaUsuarios.size(); i++){
            datos += i + ": " + listaUsuarios.get(i).datosUsuario() + "\n";
        }
        op = new Integer(JOptionPane.showInputDialog(datos));
        Usuario titular = listaUsuarios.get(op); 
        cuenta = new Cuenta(numCuenta, tipoCuenta, titular, saldoinicial);
        insertarCuenta(cuenta);//Inserta la nueva cuenta en la lista de cuentas
        return cuenta;
    }
    
    //Devuelve el codigo y el nombre de la sede
    public String datosSede(){
        return "Codigo: " + codigo + "Nombre: " + nombre + "\n";
    }
    
    @Override
    public String toString (){
        String datos = "";
        datos += "\n\nDatos de la sede\n";
        datos += "Codigo: " + this.getCodigo()+ "\n";
        datos += "Nombre: " + this.getNombre() + "\n";
        datos += "Dirección: " + this.getDireccion() + "\n";
        datos += "Ciudad: " + this.getCiudad() + "\n";
        datos += "Numero de cuentas de la sede: " + this.getCantidadCuentas()+ "\n";
        for(Cuenta cuenta : this.listaCuentas){
            datos += cuenta.toString();
        }
        return datos;
    }          
    
}
