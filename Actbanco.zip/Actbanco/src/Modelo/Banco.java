
package Modelo;

import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Banco {
    private String idBanco;
    private String nombre;
    private ArrayList<Sede> sedes;

    public Banco(String idBanco, String nombre) {
        this.idBanco = idBanco;
        this.nombre = nombre;
        this.sedes = new ArrayList<>();
    }

    public String getIdBanco() {
        return idBanco;
    }

    public void setIdBanco(String idBanco) {
        this.idBanco = idBanco;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public ArrayList<Sede> getSedes() {
        return sedes;
    }
    
    //Crea una nueva sede para un banco
    public Sede crearSede(){
        String codigo = JOptionPane.showInputDialog("Digite el codigo de la nueva sede");
        String nombre = JOptionPane.showInputDialog("Digite el nombre de la nueva sede");
        String direccion= JOptionPane.showInputDialog("Digite la direccion de la nueva sede");
        String ciudad = JOptionPane.showInputDialog("Digite la ciudad de la nueva sede");
        Sede sede = new Sede(codigo, nombre, direccion, ciudad);
        sedes.add(sede);//Inserta la nueva sede en la lista de sedes del banco
        JOptionPane.showMessageDialog(null, "Sede insertada con exito");
        return sede;
    }
    
    //retorna el id del banco y su nombre
    public String datosBanco(){
        String datos = "";
        datos += "Id banco: " + this.getIdBanco() + " Nombre: " + this.getNombre() + "\n";
        return datos;
    }

    //Retorna todos los datos del banco
    @Override
    public String toString() {
        String datos = "";
        datos += "Datos del banco\n";
        datos += "ID Banco: " + this.getIdBanco()+ "\n";
        datos += "Nombre: " + this.getNombre() + "\n";
        for(Sede sede : this.sedes){
            datos += sede.toString();
        }
        return datos;
    }
    
    


   
   
}
